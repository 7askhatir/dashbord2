import React, { Component } from 'react'  
  
export class Footer extends Component {  
    render() {  
        return (  
         <div>
          <footer class="footer">
              <div class="container">
                <div class="text-center">
                  Copyright © 2021 SALARY ECO FINANCE
                </div>
              </div>
            </footer>
            </div>
        )  
    }  
}  
  
export default Footer  